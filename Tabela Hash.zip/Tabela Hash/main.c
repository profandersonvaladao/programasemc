#include <stdio.h>
#include <stdlib.h>

#define TAMANHO_TABELA 10
#define MAX_CHAVES 20

//Na hash1: Retorna o resto da divis�o da chave pelo tamanho da tabela
//Na hash2: Multiplica a chave por 7 (um n�mero primo escolhido para diversificar a distribui��o) e depois aplica o m�dulo TAMANHO_TABELA

int hash1(int chave, int tamanho_tabela) {
    return chave % tamanho_tabela;
}

int hash2(int chave, int tamanho_tabela) {
    return (chave * 7) % tamanho_tabela;
}

void inicializar_tabela(int tabela[], int tamanho) {
    for (int i = 0; i < tamanho; i++)
        tabela[i] = -1;
}

void inserir(int tabela[], int chave, int (*funcao_hash)(int, int), int tamanho_tabela, int *colisoes) {
    int indice = funcao_hash(chave, tamanho_tabela);
    int indice_original = indice;
    int colisoes_locais = 0;

    while (tabela[indice] != -1) {
        colisoes_locais++;
        indice = (indice + 1) % tamanho_tabela;
        if (indice == indice_original) {
            printf("Tabela cheia! Nao foi possivel inserir a chave %d\n", chave);
            return;
        }
    }
    *colisoes += colisoes_locais;
    tabela[indice] = chave;
}

void imprimir_tabela(int tabela[], int tamanho) {
    printf("Indice | Valor\n");
    for (int i = 0; i < tamanho; i++) {
        if (tabela[i] != -1)
            printf("  %2d   | %d\n", i, tabela[i]);
        else
            printf("  %2d   | --\n", i);
    }
}

int main() {
    int chaves[MAX_CHAVES];
    int num_chaves;
    int colisoes1 = 0, colisoes2 = 0;

    printf("Digite o numero de chaves (max %d): ", MAX_CHAVES);
    scanf("%d", &num_chaves);

    printf("Digite as chaves (numeros inteiros):\n");
    for (int i = 0; i < num_chaves; i++) {
        scanf("%d", &chaves[i]);
    }

    int tabela1[TAMANHO_TABELA];
    int tabela2[TAMANHO_TABELA];

    inicializar_tabela(tabela1, TAMANHO_TABELA);
    inicializar_tabela(tabela2, TAMANHO_TABELA);

    for (int i = 0; i < num_chaves; i++) {
        inserir(tabela1, chaves[i], hash1, TAMANHO_TABELA, &colisoes1);
        inserir(tabela2, chaves[i], hash2, TAMANHO_TABELA, &colisoes2);
    }

    printf("\nTabela Hash usando hash1 (chave %% tamanho):\n");
    imprimir_tabela(tabela1, TAMANHO_TABELA);
    printf("Numero total de colisoes (hash1): %d\n", colisoes1);

    printf("\nTabela Hash usando hash2 (chave * 7 %% tamanho):\n");
    imprimir_tabela(tabela2, TAMANHO_TABELA);
    printf("Numero total de colisoes (hash2): %d\n", colisoes2);

    if (colisoes1 > colisoes2)
        printf("\nA funcao hash1 teve mais colisoes!\n");
    else if (colisoes2 > colisoes1)
        printf("\nA funcao hash2 teve mais colisoes!\n");
    else
        printf("\nAmbas as funcoes tiveram o mesmo numero de colisoes.\n");

    return 0;
}
